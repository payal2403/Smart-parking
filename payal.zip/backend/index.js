const express = require('express');
const app = express();
const cors = require("cors");
const db=require("./server/config/db")
const adminseed=require("./server/config/seeder")

adminseed()

const userroutes=require("./server/routes/Apiroutes")



app.use(express.urlencoded());

app.use(express.json())
app.use(cors());






app.get('/', (req, res)=>{
        res.send("Welcome to server")
    })

const apiroutes=require("./server/routes/Apiroutes")
const ownerRoutes=require("./server/routes/OwnerRoutes")
const Userroutes=require("./server/routes/Userroutes")

   
app.use("/apis",apiroutes)
app.use("/owner",ownerRoutes )
app.use("/users",Userroutes)



// for app listening
app.listen(5001, ()=>{
    console.log("I am listening to port 5001");
})

